package sdg;

import soot.Unit;

public class CallEdge {

       PDGNodeForIFC src ;
       PDGNodeForIFC trg ;




    public static void addCallEdge(Unit invoke, PDGforIFC callee ){

    }
}
